package stack;

public class NodeSewa {
    int idPenyewaan;
    NodeSewa next;

    public NodeSewa(int idPenyewaan) {
        this.idPenyewaan = idPenyewaan;
        this.next = null;
    }
}
